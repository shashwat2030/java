package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.sql.ResultSet;

public class checkout extends JFrame implements ActionListener {
    Choice ccustomer;
    JLabel lblroomnumber, lblcheckintime, lblcheckouttime;
    JButton Checkout, back;

    checkout() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        JLabel text = new JLabel("Checkout");
        text.setBounds(100, 20, 100, 30);
        text.setForeground(Color.BLUE);
        text.setFont(new Font("Tahoma", Font.PLAIN, 20));
        add(text);

        JLabel lblid = new JLabel("Customer Id");
        lblid.setBounds(30, 80, 100, 30);
        lblid.setForeground(Color.BLACK);
        lblid.setFont(new Font("Tahoma", Font.PLAIN, 11));
        add(lblid);
        ccustomer = new Choice();
        ccustomer.setBounds(150, 80, 150, 25);
        add(ccustomer);
        try {
            Connect conn = new Connect();
            ResultSet rs = conn.s.executeQuery("select * from customer");
            while (rs.next()) {
                ccustomer.add(rs.getString("number"));
                lblroomnumber.setText(rs.getString("room"));
                lblcheckintime.setText(rs.getString("checkintime"));

            }

        } catch (Exception ae) {
            ae.printStackTrace();

        }
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/tick.png"));
        Image i2 = i1.getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel tick = new JLabel(i3);
        tick.setBounds(310, 80, 20, 18);
        add(tick);

        JLabel lblroom = new JLabel("Room Number");
        lblroom.setBounds(30, 130, 100, 30);
        lblroom.setForeground(Color.BLACK);
        lblroom.setFont(new Font("Tahoma", Font.PLAIN, 11));
        add(lblroom);

        lblroomnumber = new JLabel();
        lblroomnumber.setBounds(150, 130, 100, 30);
        lblroomnumber.setForeground(Color.BLACK);
        lblroomnumber.setFont(new Font("Tahoma", Font.PLAIN, 11));
        add(lblroomnumber);

        JLabel lblcheckin = new JLabel("Checkin Time:");
        lblcheckin.setBounds(30, 180, 100, 30);
        lblcheckin.setForeground(Color.BLACK);
        lblcheckin.setFont(new Font("Tahoma", Font.PLAIN, 11));
        add(lblcheckin);


        lblcheckintime = new JLabel();
        lblcheckintime.setBounds(150, 180, 150, 30);
        lblcheckintime.setForeground(Color.BLACK);
        lblcheckintime.setFont(new Font("Tahoma", Font.PLAIN, 11));
        add(lblcheckintime);

        JLabel lblcheckout = new JLabel("Checkout Time:");
        lblcheckout.setBounds(30, 230, 100, 30);
        lblcheckout.setForeground(Color.BLACK);
        lblcheckout.setFont(new Font("Tahoma", Font.PLAIN, 11));
        add(lblcheckout);

        Date date = new Date();
        lblcheckouttime = new JLabel("" + date);
        lblcheckouttime.setBounds(150, 230, 170, 30);
        lblcheckouttime.setForeground(Color.BLACK);
        lblcheckouttime.setFont(new Font("Tahoma", Font.PLAIN, 11));
        add(lblcheckouttime);

        Checkout = new JButton("Checkout:");
        Checkout.setBackground(Color.BLACK);
        Checkout.setForeground(Color.WHITE);
        Checkout.setBounds(30, 280, 120, 30);
        Checkout.addActionListener(this);
        add(Checkout);

        back = new JButton("Backout:");
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.setBounds(170, 280, 120, 30);
        back.addActionListener(this);
        add(back);
        try {
            Connect conn = new Connect();
            ResultSet rs = conn.s.executeQuery("select * from customer");
            while (rs.next()) {
                ccustomer.add(rs.getString("number"));
                lblroomnumber.setText(rs.getString("room"));
                lblcheckintime.setText(rs.getString("checkintime"));

            }

        } catch (Exception ae) {
            ae.printStackTrace();

        }


        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icons/sixth.png"));
        Image i5 = i4.getImage().getScaledInstance(400, 250, Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel image = new JLabel(i6);
        image.setBounds(350, 50, 400, 250);
        add(image);

        setBounds(300, 200, 800, 400);
        setVisible(true);
    }

    public static void main(String[] args) {
        new checkout();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == Checkout) {
            String query = "delete from customer where number ='" + ccustomer.getSelectedItem() + "'";
            String query2 = "update room set availability = 'Available' where roomnumber ='" + lblroomnumber.getText() + "'";

            try
            {
                Connect c= new Connect();
                c.s.executeUpdate(query);
                c.s.executeUpdate(query2);
                JOptionPane.showMessageDialog(null,"chekoutdone");
            }
            catch (Exception ae)
            {
                ae.printStackTrace();
            }
        }
        else
        {
            setVisible(false);
            new Reception();
        }
    }
}
