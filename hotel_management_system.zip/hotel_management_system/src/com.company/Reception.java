package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Reception extends JFrame implements ActionListener
{ JButton newCustomer,rooms,departments,Employee,managerinfo,customer,search,status,condition,services,checkout,logout;
Reception()
{
    getContentPane().setBackground(Color.WHITE);
    setLayout(null);

     newCustomer = new JButton("New Customer Form");
    newCustomer.setBounds(10,30,200,30);
    newCustomer.setBackground(Color.BLACK);
    newCustomer.setForeground(Color.WHITE);
    newCustomer.addActionListener(this);
    add(newCustomer);

     rooms = new JButton("Rooms");
    rooms.setBounds(10,70,200,30);
    rooms.setBackground(Color.BLACK);
    rooms.setForeground(Color.WHITE);
    rooms.addActionListener(this);
    add(rooms);
     departments = new JButton("Departments");
    departments.setBounds(10,110,200,30);
    departments.setBackground(Color.BLACK);
    departments.setForeground(Color.WHITE);
    departments.addActionListener(this);
    add(departments);
     Employee = new JButton("ALL Employee");
    Employee.setBounds(10,150,200,30);
    Employee.setBackground(Color.BLACK);
    Employee.setForeground(Color.WHITE);
    Employee.addActionListener(this);
    add(Employee);

     customer = new JButton("Customer Residing");
    customer.setBounds(10,190,200,30);
    customer.setBackground(Color.BLACK);
    customer.setForeground(Color.WHITE);
    customer.addActionListener(this);
    add(customer);
     managerinfo = new JButton("Manager Info");
    managerinfo.setBounds(10,230,200,30);
    managerinfo.setBackground(Color.BLACK);
    managerinfo.setForeground(Color.WHITE);
    managerinfo.addActionListener(this);
    add(managerinfo);
    checkout = new JButton("Checkout");
    checkout.setBounds(10,270,200,30);
    checkout.setBackground(Color.BLACK);
    checkout.setForeground(Color.WHITE);
    checkout.addActionListener(this);
    add(checkout);
     status = new JButton("Update Customer Status");
    status.setBounds(10,310,200,30);
    status.setBackground(Color.BLACK);
    status.setForeground(Color.WHITE);
    status.addActionListener(this);
    add(status);
     condition = new JButton("Update Room Status");
    condition.setBounds(10,350,200,30);
    condition.setBackground(Color.BLACK);
    condition.setForeground(Color.WHITE);
    condition.addActionListener(this);
    add(condition);
     services = new JButton("Hotel Service");
    services.setBounds(10,390,200,30);
    services.setBackground(Color.BLACK);
    services.setForeground(Color.WHITE);
    services.addActionListener(this);
    add(services);
     search = new JButton("Search Room");
    search.setBounds(10,430,200,30);
    search.setBackground(Color.BLACK);
    search.setForeground(Color.WHITE);
    search.addActionListener(this);
    add(search);
     logout = new JButton("Logout");
    logout.setBounds(10,470,200,30);
    logout.setBackground(Color.BLACK);
    logout.setForeground(Color.WHITE);
    add(logout);
    ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/fourth.jpg"));
    JLabel image= new JLabel(i1);
    image.setBounds(250,30,500,500);
    add(image);
    setBounds(350,200,800,570);
    setVisible(true);
}
    public static void main(String[] args) {
    new Reception();

    }

    @Override
    public void actionPerformed(ActionEvent e)
    {

        if (e.getSource() == newCustomer )
      {
          setVisible(false);
          new Add_Customer();
      } else if (e.getSource() ==rooms) {
            setVisible(true);
            new Room();
        }
        else if(e.getSource()==departments)
    {
        setVisible(true);
        new Department();
    } else if (e.getSource()== Employee) {
            setVisible(false);
            new Employee_Info();

        } else if (e.getSource()==managerinfo) {
            setVisible(false);
            new Manager_Info();

        } else if (e.getSource()==customer) {
            setVisible(false);
            new Customer_Info();

        } else if (e.getSource() == search) {
            setVisible(false);
            new Search_Room();

        } else if (e.getSource()==status) {
            setVisible(false);
            new Update_check();

        } else if (e.getSource()==condition) {
            setVisible(false);
            new UpdateRoom();

        } else if (e.getSource()==services) {
            setVisible(false);
            new Search_Staff();

        } else if (e.getSource()==checkout) {
            setVisible(false);
            new checkout();

        } else if (e.getSource()==logout) {
            setVisible(false);
            System.exit(0);

        }
    }
}
