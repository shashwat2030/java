package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dashboard extends JFrame implements ActionListener
{
Dashboard()
{
    setBounds(0,0,1600,1000);
    setLayout(null);

    ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/third.jpg"));
    Image i2 =i1.getImage().getScaledInstance(1600,1000,Image.SCALE_DEFAULT);
    ImageIcon i3= new ImageIcon(i2);
    JLabel image= new JLabel(i3);
    image.setBounds(0,0,1600,1000);
    add(image);

    JLabel text =new JLabel("Hotel Taj Group Welcomes You");
    text.setBounds(400,100,1000,50);
    text.setFont(new Font("serif",Font.BOLD,50));
    text.setForeground(Color.WHITE);
    image.add(text);

    JMenuBar mb = new JMenuBar();
    mb.setBounds(0,0,1550,30);
    image.add(mb);

    JMenu Hotel= new JMenu("Hotel Management");
    Hotel.setForeground(Color.RED);
    mb.add(Hotel);
    Hotel.addActionListener(this);

    JMenuItem reception =new JMenuItem("Reception");
    Hotel.add(reception);
    reception.addActionListener(this);

    JMenuItem contacts =new JMenuItem("Complaint");
    Hotel.add(contacts);
    contacts.addActionListener(this)
    ;
    JMenuItem Suggestion=new JMenuItem("Suggestion");
    Hotel.add(Suggestion);
Suggestion.addActionListener(this);

    JMenu Admin= new JMenu("Admin");
    Admin.setForeground(Color.BLUE);
    mb.add(Admin);
    Admin.addActionListener(this);

    JMenuItem Add_Employee =new JMenuItem("Add Employee");
    Add_Employee.addActionListener(this);
    Admin.add(Add_Employee);

    JMenuItem Add_Rooms =new JMenuItem("Add Rooms");
    Admin.add(Add_Rooms);
    Add_Rooms.addActionListener(this);
    JMenuItem Add_Staff =new JMenuItem("Add Staff");
    Admin.add(Add_Staff);
Add_Staff.addActionListener(this);

    setVisible(true);
}
    public static void main(String[] args)
    {
      new Dashboard();
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
     if (e.getActionCommand().equals("Add Employee"))
     {
         new Add_Employee();
     }
     else if(e.getActionCommand().equals("Add Rooms"))
      {
          new Add_Rooms();
      } else if (e.getActionCommand().equals("Add Staff")) {
         new Add_Staff();
     } else if (e.getActionCommand().equals("Reception"))
     {
        new Reception();
     }
    }

}
