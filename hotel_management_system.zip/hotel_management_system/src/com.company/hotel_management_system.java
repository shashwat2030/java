package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class hotel_management_system extends JFrame implements ActionListener
{
 hotel_management_system()
 {
   //setSize(522,390);
   //setLocation(100,100);

     setBounds(100,100,1100,700);
      setLayout(null);

     ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/first.jpeg"));
     JLabel image= new JLabel(i1);
     add(image);
     image.setBounds(0,0,1100,700);

     JLabel text =new JLabel("Hotel Management System");
     text.setBounds(450,20,625,200);
     text.setForeground(Color.BLACK);
     text.setFont(new Font(" serif",Font.PLAIN,50));
     image.add(text);

     JButton next = new JButton("Next");
     next.setBounds(800,600,100,50);
     next.setBackground(Color.black);
     next.setForeground(Color.magenta);
     next.addActionListener(this);
     next.setFont(new Font("serif", Font.PLAIN,30));
     image.add(next);
     setVisible(true);

     while (true)
     {
         text.setVisible(false);
       try
       {
           Thread.sleep(500);
       } catch (Exception e)
       {
           e.printStackTrace();
       }
       text.setVisible(true);
         try
         {
             Thread.sleep(500);
         } catch (Exception e)
         {
             e.printStackTrace();
         }

     }




 }
    public static void main(String[] args)
    {
        new hotel_management_system();

    }

    @Override
    public void actionPerformed(ActionEvent e)
    {

        setVisible(false);
        new  Login();
    }
}
