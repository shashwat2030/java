package com.company;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Search_Room extends JFrame implements ActionListener
{
    JTable table;
    JButton back,submit;
    JComboBox  bedtypecombon;
    JCheckBox available;
    Search_Room()
    {
        getContentPane().setBackground(Color.white);
        setLayout(null);

        JLabel heading =new JLabel("Search For Room:");
        heading.setFont(new Font("serif",Font.BOLD,18));
        heading.setBounds(400,30,200,30);
        add(heading);

        JLabel l1 =new JLabel("Room No:");
        l1.setBounds(50,160,100,20);
        add(l1);
        JLabel l2 = new JLabel("Availability");
        l2.setBounds(270,160,100,20);
        add(l2);
        JLabel l3 =new JLabel("Status");
        l3.setBounds(450,160,100,20);
        add(l3);
        JLabel l4 =new JLabel("Price");
        l4.setBounds(670,160,100,20);
        add(l4);
        JLabel l5 =new JLabel("Bed type");
        l5.setBounds(870,160,100,20);
        add(l5);
        JLabel l6 =new JLabel("Bed type");
        l6.setBounds(50,100,100,20);
        add(l6);

        bedtypecombon=new JComboBox(new String[]{"Single Bed","Double Bed"});
        bedtypecombon.setBounds(150,100,150,25);
        bedtypecombon.setBackground(Color.WHITE);
        add(bedtypecombon);
        available =new JCheckBox("Display only available");
        available.setBounds(650,100,150,25);
        available.setBackground(Color.WHITE);
        add(available);


        table =new JTable();
        table.setBounds(0,200,1000,300);
        add(table);
        try
        {
            Connect conn =new Connect();
            ResultSet rs =conn.s.executeQuery("select * from room");
            table.setModel(DbUtils.resultSetToTableModel(rs));

        }
        catch(Exception ae)
        {
            ae.printStackTrace();;
        }
        back =new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setBackground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(500,520,120,30);
        add(back);
        submit =new JButton("Submit");
        submit.setBackground(Color.BLACK);
       submit .setBackground(Color.WHITE);
       submit .addActionListener(this);
       submit .setBounds(300,520,120,30);
        add(submit);
        setBounds(300,200,1000,600);
        setVisible(true);

    }
    @Override
    public void actionPerformed(ActionEvent e)
    {

        if(e.getSource()== submit)
        {
            try
            {
                String query ="select * from room where bed_type= '"+bedtypecombon.getSelectedItem()+"'";
                String query2="select *from room where availability ='Available' AND bed_type ='"+bedtypecombon.getSelectedItem()+"'";
                Connect conn = new Connect();
                ResultSet rs;
                if (available.isSelected())
                {
                    rs =conn.s.executeQuery(query2);
                }
                else
                {
                    rs =conn.s.executeQuery(query);
                }
                table.setModel(DbUtils.resultSetToTableModel(rs));
            }
            catch(Exception ae)
            {
                ae.printStackTrace();

            }
        }
        else
        {
            setVisible(false);
            new Reception();
        }
    }

    public static void main(String[] args) {
        new Search_Room();

    }
}
