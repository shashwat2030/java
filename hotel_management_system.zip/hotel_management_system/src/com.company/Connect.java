package com.company;
import java.sql.*;

public class Connect {
    Connection c;
    Statement s;
    Connect()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            c=DriverManager.getConnection("jdbc:mysql://localhost3306/'hotelmanagementsystem'","root","shAshi@1000999");
            s =c.createStatement();

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        new Connect();
    }
}
