package com.company;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Search_Staff  extends JFrame implements ActionListener {

    JTable table;
    JButton back,submit;
    Choice servicetypes;
    JCheckBox available;
    Search_Staff()
    {
        getContentPane().setBackground(Color.white);
        setLayout(null);

        JLabel heading =new JLabel("Hotel Services:");
        heading.setFont(new Font("Tahoma",Font.PLAIN,20));
        heading.setBounds(400,30,200,30);
        add(heading);

        JLabel l1 =new JLabel("Name:");
        l1.setBounds(81,160,100,20);
        add(l1);
        JLabel l2 = new JLabel("Age");
        l2.setBounds(162,160,100,20);
        add(l2);
        JLabel l3 =new JLabel("Gender");
        l3.setBounds(243,160,100,20);
        add(l3);
        JLabel l4 =new JLabel("Office");
        l4.setBounds(374,160,100,20);
        add(l4);
        JLabel l5 =new JLabel("Experience");
        l5.setBounds(486,160,100,20);
        add(l5);
        JLabel l6 =new JLabel("Availability");
        l6.setBounds(648,160,100,20);
        add(l6);
        JLabel l7 =new JLabel("Department");
        l7.setBounds(810,160,100,20);
        add(l7);
        JLabel l8 =new JLabel("Service Types:");
        l8.setBounds(50,100,100,20);
        add(l8);

        servicetypes=new Choice();
        servicetypes.setBounds(150,100,200,25);
        add(servicetypes);
        try
        {
            Connect conn =new Connect();
            ResultSet rs =conn.s.executeQuery("select * from staff");
            while(rs.next())
            {
                servicetypes.add(rs.getString("office"));
            }
        }
        catch(Exception ae)
        {
            ae.printStackTrace();
        }



        table =new JTable();
        table.setBounds(0,200,1000,300);
        add(table);
        try
        {
            Connect conn =new Connect();
            ResultSet rs =conn.s.executeQuery("select * from staff");
            table.setModel(DbUtils.resultSetToTableModel(rs));

        }
        catch(Exception ae)
        {
            ae.printStackTrace();;
        }
        back =new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setBackground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(500,520,120,30);
        add(back);
        submit =new JButton("Submit");
        submit.setBackground(Color.BLACK);
        submit .setBackground(Color.WHITE);
        submit .addActionListener(this);
        submit .setBounds(300,520,120,30);
        add(submit);
        setBounds(300,200,1000,600);
        setVisible(true);

    }


    public static void main(String[] args)
    {
        new Search_Staff();
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()== submit)
        {
            try
            {
String query ="select * from staff where office ='"+servicetypes.getSelectedItem()+"'";
                Connect conn = new Connect();
                ResultSet rs;
                rs =conn.s.executeQuery(query);

                table.setModel(DbUtils.resultSetToTableModel(rs));
            }
            catch(Exception ae)
            {
                ae.printStackTrace();

            }
        }
        else
        {

            setVisible(false);
            new Reception();
        }
    }


}
