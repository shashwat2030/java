package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Add_Rooms  extends JFrame implements ActionListener
{
    JButton add,cancel;
    JTextField tfroomno,tfprice;
    JComboBox  cleancombon,availablecombon,typecombon;
    Add_Rooms()
    {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        JLabel heading =new JLabel("Add Rooms");
        heading.setFont(new Font("serif",Font.BOLD,18));
        heading.setBounds(150,20,200,20);
        add(heading);

        JLabel lblroomno =new JLabel("Add Room NO");
        lblroomno.setFont(new Font("serif",Font.PLAIN,18));
        lblroomno.setBounds(60,80,120,20);
        add(lblroomno);
         tfroomno =new JTextField();
        tfroomno.setBounds(200,80,150,30);
        add(tfroomno);

        JLabel lblavailable =new JLabel("Available");
        lblavailable.setFont(new Font("serif",Font.PLAIN,18));
        lblavailable.setBounds(60,130,120,20);
        add(lblavailable);

        String[] availableOptions = {"Available" , " Occupied"};
         availablecombon=new JComboBox(availableOptions);
        availablecombon.setBounds(200,130,150,30);
        availablecombon.setBackground(Color.WHITE);
        add(availablecombon);

        JLabel lblclean =new JLabel("Clean");
        lblclean.setFont(new Font("serif",Font.PLAIN,18));
     lblclean.setBounds(60,180,120,20);
        add(lblclean);

        String[] cleanOptions = {"clean" , " unclean"};
         cleancombon=new JComboBox(cleanOptions);
        cleancombon.setBounds(200,180,150,30);
        cleancombon.setBackground(Color.WHITE);
        add(cleancombon);

        JLabel lblprice =new JLabel("Price");
        lblprice.setFont(new Font("serif",Font.PLAIN,18));
        lblprice.setBounds(60,230,120,20);
        add(lblprice);
         tfprice =new JTextField();
        tfprice.setBounds(200,230,150,30);
        add(tfprice);

        JLabel lbltype =new JLabel(" Bed Type");
        lbltype.setFont(new Font("serif",Font.PLAIN,18));
        lbltype.setBounds(60,280,120,20);
        add(lbltype);

        String[] typeOptions = {"Single" , " Double"};
         typecombon=new JComboBox(typeOptions);
        typecombon.setBounds(200,280,150,30);
        typecombon.setBackground(Color.WHITE);
        add(typecombon);


 add =new JButton("Add Room");
add.setForeground(Color.WHITE);
add.setBackground(Color.BLACK);
add.setBounds(60,350,130,30);
add.addActionListener(this);
add(add);
        cancel =new JButton("Cancel Room");
        cancel.setForeground(Color.WHITE);
        cancel.setBackground(Color.BLACK);
        cancel.setBounds(220,350,130,30);
        cancel.addActionListener(this);
        add(cancel);

ImageIcon i1 =new ImageIcon(ClassLoader.getSystemResource("icons/twelve.jpg"));
JLabel image= new JLabel(i1);
image.setBounds(430,30,500,300);
add(image);


        setBounds(330,200,940,470);
        setVisible(true);
    }

    public static void main(String[] args)
    {

        new  Add_Rooms();
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource()==add)
        {
String roomnumber =tfroomno.getText();
String availability=(String) availablecombon.getSelectedItem();
String status = (String)  cleancombon.getSelectedItem();
String price =tfprice.getText();
String type =(String) typecombon.getSelectedItem();
try
{
    Connect conn =new Connect();
    String str = "insert into room values ('"+roomnumber+"','"+availability+"','"+status+"','"+price+"','"+type+"')";
    conn.s.executeUpdate(str);
    JOptionPane.showMessageDialog(null,"New Room Added");
    setVisible(false);
}
catch(Exception ae)
            {
                ae.printStackTrace();

        }

        }

        else
        {
            setVisible(false);
        }
    }
}
