package com.company;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Department extends JFrame implements ActionListener
{
    JTable table;
    JButton back;
    Department()
    {
        getContentPane().setBackground(Color.white);
        setLayout(null);
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/eight.jpg"));
        Image i2=i1.getImage().getScaledInstance(600,600,Image.SCALE_DEFAULT);
        ImageIcon i3 =new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(500,0,600,600);
        add(image);
        JLabel l1 =new JLabel("Department");
        l1.setBounds(180,10,100,20);
        add(l1);
        JLabel l2 = new JLabel("Budget");
        l2.setBounds(370,10,100,20);
        add(l2);

        table =new JTable();
        table.setBounds(0,50,700,350);
        add(table);
        try
        {
            Connect conn =new Connect();
            ResultSet rs =conn.s.executeQuery("select * from department");
            table.setModel(DbUtils.resultSetToTableModel(rs));

        }
        catch(Exception ae)
        {
            ae.printStackTrace();;
        }
        back =new JButton("Back");
        back.setBackground(Color.BLACK);
        back.setBackground(Color.WHITE);
        back.addActionListener(this);
        back.setBounds(280,400,120,30);
        add(back);
        setBounds(300,200,700,480);
        setVisible(true);
    }
    public static void main(String[] args)
    {
        new Department();
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
        setVisible(false);
        new Reception();
    }
}
